/**
 * @(#)ATM.java
 *
 *
 *
 * @author Laurente, Allan Poe
 * @version 1.00 2022/5/31
 */

package ATM;

import java.io.IOException;
public class ATM extends ChoiceMenu{
	/**
	 *This is a program a short implementation of 
	 *ATM functionality using Java.
	 *
	 *@param args
	 */
	public static void main(String args[]) throws IOException
	{
		/**
		 *This is the main method 
		 *which is very importatnt for
		 *execution for this java program.
		 */
		 
	ChoiceMenu choice=new ChoiceMenu();
	choice.getLogin();
}


}
