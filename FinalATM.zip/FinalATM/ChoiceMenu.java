package ATM;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;


public class ChoiceMenu extends Account {
	Scanner menuInput=new Scanner(System.in);
	DecimalFormat money=new DecimalFormat("'Php '###,##0.00");
	
	HashMap<Integer, Integer> data=new HashMap<Integer, Integer>();
	
	//Validate login information customer number and pin number
	
	public void getLogin() throws IOException
	{
		int x=1;
		do
		{
			try
			{
				/*
				 * Accounts in a HashMap form, key = customer number, value = pin
				 * number
				 */
				
				data.put(123123123, 12345);
				data.put(123412345, 1236);
				data.put(345678910, 54321);
				
				
				System.out.println("\nWelcome to the ATM Project!");
				
				System.out.print("Enter your Customer Number: ");
				setCustomerNumber(menuInput.nextInt());
				
				System.out.print("Enter your pin: ");
				setPinNumber(menuInput.nextInt());
			}
			catch(Exception e)
			{
				System.out.println("\n" + "Invalid character(s). Only numbers." + "\n");
				x=2;
			}
			//loop for checking customerNumber and pinNumber
			for(Entry<Integer,Integer> entry:data.entrySet())
			{
				if(entry.getKey()==getCustomerNumber() && entry.getValue()==getPinNumber()) {
					getAccountType();	
				}			
			}
	
		}while(x==1);
	}
	
	//Account type menu with selection
	
	public void getAccountType()
	{
		System.out.println("\nSelect the Account you want to access: ");
		System.out.println("Type 1- Checking Account");
		System.out.println("Type 2- Saving Account");
		System.out.println("Type 3- Exit");
		System.out.print("Choice: ");
		
		selection=menuInput.nextInt();
		
		switch(selection)
		{
		case 1: // For Checking Account
			getChecking();
			break;
		
		case 2: //For Saving Account
			getSaving();
			break;
		
		case 3: //For Exit
			System.out.println("Thank You for using this ATM. \n\n");
			break;
		
			default:
				System.out.println("\n" + "Inavlid Choice. " + "\n");
				getAccountType();	
		}
	}
	
	//Display Checking Account Menu with Selections
	
	public void getChecking()
	{
		System.out.println("\nChecking Account: ");
		System.out.println("Type 1- View Balance");
		System.out.println("Type 2- Withdraw Money");
		System.out.println("Type 3- Deposit Money");
		System.out.println("Type 4- Exit");
		System.out.print("Choice: ");
		
		selection=menuInput.nextInt();
		
		switch(selection)
		{
		case 1: //For Checking Balance
			System.out.println();
			System.out.println("Checking Account Balance: " + money.format(getCheckingBalance()) + "\n");
			getAccountType();
			break;
			
	
		case 2: // For Checking Withdrawal
			getCheckingWithdrawlInput();
			getAccountType();
			break;
			
		case 3: //For Checking Deposit
			getCheckingDepositInput();
			getAccountType();
			break;
			
		case 4: //For Exit
			System.out.println("Thank You for using this ATM. ");
			break;
			
	    default:
	    	System.out.println("\n" + "Invalid choice." + "\n");
	    	getChecking();
		}
	}
	
	//Display saving account menu with selection
	
	public void getSaving()
	{
		System.out.println("\nSaving Account: ");
		System.out.println("Type 1- View Balance");
		System.out.println("Type 2- Withdraw Money");
		System.out.println("Type 3- Deposit Money");
		System.out.println("Type 4- Exit");
		System.out.print("Choice: ");
		
		selection=menuInput.nextInt();
		
		switch(selection)
		{
		case 1: //For Saving Account Balance
			System.out.println();
			System.out.println("Saving Account Balance: " + money.format(getSavingBalance()) + "\n");
			getAccountType();
			break;
			
	
		case 2: //For Saving Withdrawal
			getSavingWithdrawlInput();
			getAccountType();
			break;
			
		case 3: //For Saving Deposit
			getSavingDepositInput();
			getAccountType();
			break;
			
		case 4: //For Exit
			System.out.println("Thank You for using this ATM. ");
			break;
			
	    default:
	    	System.out.println("\n" + "Invalid choice." + "\n");
	    	getSaving();
		}
	}
	int selection;
		
}
	
	
